package Generate;

public interface CommandPattern {
	public void orderType();
}
