package Computer;

public class LaptopAsus extends Computer {
    public  LaptopAsus(){
        description = "LaptopAsusX790";
    }

    @Override
    public int price() {
        return 20000000;
    }
}
