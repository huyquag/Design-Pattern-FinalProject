package Computer;

public abstract class EComponents extends Computer {
	public abstract String getDescription();
}
