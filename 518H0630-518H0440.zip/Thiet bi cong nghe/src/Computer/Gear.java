package Computer;

public abstract class Gear extends Computer {
	public abstract String getDescription();
}
