package Dienthoaididong;


public class Xiaominote8 extends Dienthoaitamtrung  {
	    @Override
	    public int price() {
	        return 5000000;
	    }

	    @Override
	    public String getDescription() {
	        return "Xiaominote8";
	}
}
