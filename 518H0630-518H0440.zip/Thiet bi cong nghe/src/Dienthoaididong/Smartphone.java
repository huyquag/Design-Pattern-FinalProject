package Dienthoaididong;

import java.util.Scanner;

public interface Smartphone {
	public String getDescription();
	public int price();
	public void Delivery();
}
