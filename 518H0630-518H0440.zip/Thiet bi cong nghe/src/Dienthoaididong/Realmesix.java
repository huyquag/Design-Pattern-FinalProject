package Dienthoaididong;

public class Realmesix extends Dienthoaitamtrung   {

    public int price() {
        return 6000000;
    }

    public String getDescription() {
        return "Realme6";
    }
}	

